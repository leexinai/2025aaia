# week03-2.py
# F021
a = input()
a = int(a)

if a%2==1: print("odd" , end='')
else: print("even" , end='')
