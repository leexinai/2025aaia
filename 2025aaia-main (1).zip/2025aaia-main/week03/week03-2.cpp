// week03-2.cpp
// F021
# include <stdio.h>
int main()
{
    int a;
    scanf("%d" , &a );

    if(a%2==1) printf("odd");
    else printf("even");

}
