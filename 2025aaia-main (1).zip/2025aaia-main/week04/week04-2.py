# week04-2.py
# SOIT107_Base_018

N = input()
N = int(N)

for i in range(1, N+1, 1):
	if i%2==0: print(i, end=' ')
